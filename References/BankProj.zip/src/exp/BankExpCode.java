package exp;

public enum BankExpCode {
	NOT_ACC, EXIST_ACC, WITHDRAW, DEPOSIT, MAIN_MENU, ACC_MENU , LIST_MENU
}
