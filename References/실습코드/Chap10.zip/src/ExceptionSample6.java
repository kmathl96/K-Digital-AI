import java.util.Scanner;

public class ExceptionSample6 {

	static Scanner sc = new Scanner(System.in);
	public static void menu() {
		int sel= Integer.parseInt(sc.nextLine());
		subMenu();
	}
	public static void subMenu() {
		int sel= Integer.parseInt(sc.nextLine());
	}
	public static void main(String[] args) {
		try {
			menu();
			
		} catch(NumberFormatException e) {
			System.out.println(e.getMessage());
		}
	}
}