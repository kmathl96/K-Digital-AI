
public class ExceptionSample5 {
	public static void main(String[] args) {
		try {
			String str=null;
			System.out.println(str.toString());
			System.out.println("try");
			return;
		} catch(Exception e) {
			System.out.println("예외처리");
			return;
		} finally {//try나 catch 문을 처리하고 나면 마무리 처리하는 부분이다. return이 발생해도 처리됨
			System.out.println("마무리처리"); 
		}
		//System.out.println("마무리처리");
		//System.out.println("프로그램 종료");
	}
}