interface IBase {
	void method();
}
abstract class CBase {
	abstract void cmethod();
}
public class AnoninmousTest {

	public static void main(String[] args) {
		IBase b = new IBase() {  //익명클래스의 정의와 생성, IBase로부터 상속받아 오버라이딩 후 객체 생성
			@Override
			public void method() {
				System.out.println("method 구현 메서드");
			}
		};
		b.method();
		
		CBase c = new CBase() {

			@Override
			void cmethod() {
				System.out.println("cmethod 구현 메서드");
				
			}
			
		};
		c.cmethod();
	}
}
