package shapes;

public interface IAngle {

}
