package shapes;

abstract public class Shape {
	String color;
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Shape() {}
	public Shape(String color) {
		this.color=color;
	}
	abstract public void draw();
}
