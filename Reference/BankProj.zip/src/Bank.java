import java.util.Scanner;

import acc.Account;
import acc.SpecialAccount;

public class Bank {
	Scanner sc = new Scanner(System.in);
	Account[] accs = new Account[100];
	int accCnt;
	
	public int getAccCnt() {
		return accCnt;
	}
	public void createAccount() {
		System.out.println("--------");
		System.out.println("일반계좌생성");
		System.out.println("--------");
		System.out.print("계좌번호:");
		String id = sc.nextLine();
		System.out.print("이름:");
		String name = sc.nextLine();
		System.out.print("초기입금액:");
		int money = Integer.parseInt(sc.nextLine());
		accs[accCnt++] = new Account(id,name,money);
		System.out.println("결과:일반계좌가 개설되었습니다.");
	}
	public void createSpecialAccount() {
		System.out.println("--------");
		System.out.println("특수계좌생성");
		System.out.println("--------");
		System.out.print("계좌번호:");
		String id = sc.nextLine();
		System.out.print("이름:");
		String name = sc.nextLine();
		System.out.print("초기입금액:");
		int money = Integer.parseInt(sc.nextLine());	
		System.out.print("등급(VIP:1,Gold:2,Silver:3,Normal:4):");
		int ngrade=Integer.parseInt(sc.nextLine());
		String grade="Normal";
		switch(ngrade) {
		case 1: grade="VIP"; break;
		case 2: grade="Gold"; break;
		case 3: grade="Silver"; break;
		case 4: grade="Normal"; break;
		}
		accs[accCnt++] = new SpecialAccount(id,name,money,grade);
		System.out.println("결과:특수계좌가 개설되었습니다.");
	}
	public void accsList() {
		System.out.println("---------------------------");
		System.out.println("1.일반계좌 | 2.특수계좌 | 3.전체");
		System.out.println("---------------------------");
		System.out.print("선택>>");
		int sel= Integer.parseInt(sc.nextLine());
		//추가
		
		
//		System.out.println("--------");
//		System.out.println("계좌목록");
//		System.out.println("--------");	
//		for(int i=0; i<accCnt; i++) {
//			System.out.println(accs[i].accInfo());
//		}
	}
	private Account searchAccById(String id) {
		for(int i=0; i<accCnt; i++) {
			if(accs[i].getId().equals(id)) {
				return accs[i];
			}
		}
		return null;
	}
	public void deposit() {
		System.out.println("--------");
		System.out.println("입금");
		System.out.println("--------");
		System.out.print("계좌번호:");
		String id = sc.nextLine();
		System.out.print("예금액:");
		int money = Integer.parseInt(sc.nextLine());
		Account acc = searchAccById(id);
		if(acc==null) {
			System.out.println("결과:없는 계좌입니다.");
			return;
		}
		boolean flag= acc.deposit(money);
		if(flag)
			System.out.println("결과:예금을 성공하였습니다.");
		else 
			System.out.println("결과:예금을 실패하였습니다.");
	}
	public void withdraw() {
		System.out.println("--------");
		System.out.println("출금");
		System.out.println("--------");
		System.out.print("계좌번호:");
		String id = sc.nextLine();
		System.out.print("출금액:");
		int money = Integer.parseInt(sc.nextLine());
		Account acc = searchAccById(id);
		if(acc==null) {
			System.out.println("결과:없는 계좌입니다.");
			return;
		}
		boolean flag= acc.withdraw(money);
		if(flag)
			System.out.println("결과:출금을 성공하였습니다.");
		else
			System.out.println("결과:잔액이 부족합니다.");
	}
	public void accInfo() {
		System.out.println("--------");
		System.out.println("계좌조회");
		System.out.println("--------");
		System.out.print("계좌번호:");
		String id=sc.nextLine();
		Account acc = searchAccById(id);
		if(acc==null) {
			System.out.println("결과:없는 계좌입니다.");
			return;
		}
		System.out.println(acc.accInfo());
		System.out.println("결과:계좌가 조회되었습니다.");
	}	
	public int menu() {
		System.out.println("------------------------------------------------------");
		System.out.println("1.계좌생성 | 2.계좌조회 | 3.계좌목록 | 4.예금 | 5.출금 | 0.종료");
		System.out.println("------------------------------------------------------");
		System.out.print("선택>>");
		return Integer.parseInt(sc.nextLine());
	}
	public void accMenu() {
		System.out.println("-------------------");
		System.out.println("1.일반계좌 | 2.특수계좌");
		System.out.println("-------------------");
		System.out.print("선택>>");
		int sel= Integer.parseInt(sc.nextLine());
		if(sel==1) {
			createAccount();
		} else {
			createSpecialAccount();
		}
	}
	public static void main(String[] args) {
		Bank bank = new Bank();
		int sel;
		while((sel=bank.menu())!=0) {
			switch(sel) {
			case 1: bank.accMenu(); break;
			case 2: bank.accInfo(); break;
			case 3: bank.accsList(); break;
			case 4: bank.deposit(); break;
			case 5: bank.withdraw(); break;
			}
		}
	}
}
