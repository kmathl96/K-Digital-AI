interface DoubleClickable {
	void idoubleClick();
}
class Button {
	Clickable c;
	DoubleClickable dc;
	public void click() {
		if(c!=null) {
			c.iclick();
		}
		System.out.println("꾹 눌려짐.");
	}
	public void doubleClick() {
		if(dc!=null) {
			dc.idoubleClick();
		}
	}
	public void addClickListener(Clickable c) {
		this.c=c;
	}
	public void addDoubleClickListener(DoubleClickable dc) {
		this.dc=dc;
	}
	
	interface Clickable {  
		void iclick();
	}
}

//class JoinClicable implements Button.Clickable {
//	@Override
//	public void iclick() {
//		System.out.println("회원가입 처리");
//	}
//}
public class InterfaceSample2 {

	public static void main(String[] args) {
		Button libtn = new Button();
		libtn.addClickListener(new Button.Clickable() {
			@Override
			public void iclick() {
				System.out.println("로그인 처리");
			}		
		});
		libtn.click();
		
		Button joinBtn = new Button();
		joinBtn.addClickListener(new Button.Clickable() {
			@Override
			public void iclick() {
				System.out.println("회원가입 처리");				
			}			
		});
		joinBtn.click();  // 꾹 눌려짐. 회원가입처리
	}
}
