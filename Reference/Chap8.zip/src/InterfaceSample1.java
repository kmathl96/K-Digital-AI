public class InterfaceSample1 {

	public static void sayHello(MessageBean bean) {  //upcasting
		bean.sayHello("Java");
	}
	public static void main(String[] args) {
		//MessageBean mb = new MessageBean();  //interface는 생성 불가
		sayHello(new MessageBean_En());
	}
}
