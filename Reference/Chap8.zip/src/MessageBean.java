public interface MessageBean {
	public void sayHello(String name); //interface의 추상 메소드
}
